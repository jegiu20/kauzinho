#!bin/bash
while : 
do
    node index.js
    sleep 0
done
