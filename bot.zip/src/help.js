const help = (p) => {
	return `
	_*EDICTH BOT*_
	
*COMANDOS*

*${p}sticker*
*${p}toimg*
*${p}tovideo*
*${p}wallpaper*
*${p}simsimi* <texto>
*${p}printweb* <link com http>
*${p}play* <musica>
*${p}swm* author|pack
*${p}ytsrc* <musica>
*${p}get* <link>
*${p}github* <user>
*${p}ttp* <nome>

*GRUPOS:*

*${p}welcome [1/0]*
*${p}add*
*${p}kick*
*${p}promote*
*${p}demote*
*${p}linkgroup*
*${p}leave*
*${p}marcar*

*DONO DO BOT:*

=> <async>
>  <eval>
$  <Terminal>

*${p}bc*
*${p}setprefix*
*${p}mek*

➣   ▉║█▐▉▉▐▐▍█║▍▉▏▍▍
➣   ▉║█▐▉▉▐▐▍█║▍▉▏▍▍

`
}

exports.help = help
